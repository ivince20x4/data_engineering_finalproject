# Export data from Google Cloud SQL to csv format so that we can populate the data into graph database (Neo4J)

SELECT personid, genderid, raceid, stateid, incomeid, person_lifeexp, year
FROM lifeexpdw.fact_personlifeexp;

SELECT DISTINCT genderid, gendername
FROM lifeexpdw.dim_gender;

SELECT DISTINCT incomeid, incomebracket
FROM lifeexpdw.dim_income;

SELECT DISTINCT raceid, racename
FROM lifeexpdw.dim_race;

SELECT DISTINCT stateid, statename
FROM lifeexpdw.dim_state;

SELECT DISTINCT round(person_lifeexp,0) as lifeexp
FROM lifeexpdw.fact_personlifeexp;

SELECT year
FROM lifeexpdw.dim_year;